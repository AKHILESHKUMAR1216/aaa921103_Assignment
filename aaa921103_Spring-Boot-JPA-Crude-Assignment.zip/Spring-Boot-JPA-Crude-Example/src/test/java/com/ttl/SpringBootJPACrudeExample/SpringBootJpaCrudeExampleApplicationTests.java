package com.ttl.SpringBootJPACrudeExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaCrudeExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
