package com.ttl.SpringBootJPACrudExample;



import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.web.bind.annotation.*;



@SuppressWarnings("unused")
@SpringBootApplication
public class SpringBootJPACrudExampleApplication {

public static void main(String[] args) throws Exception {
SpringApplication.run(SpringBootJPACrudExampleApplication.class, args);
}
}