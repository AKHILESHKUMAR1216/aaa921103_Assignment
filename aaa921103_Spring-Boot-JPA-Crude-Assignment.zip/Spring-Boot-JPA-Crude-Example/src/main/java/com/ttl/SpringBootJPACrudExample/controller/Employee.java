package com.ttl.SpringBootJPACrudExample.controller;

public class Employee {

}
