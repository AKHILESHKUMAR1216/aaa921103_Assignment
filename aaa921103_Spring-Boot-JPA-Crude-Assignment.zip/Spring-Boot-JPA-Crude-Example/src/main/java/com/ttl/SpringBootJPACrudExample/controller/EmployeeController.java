package com.ttl.SpringBootJPACrudExample.controller;



import java.util.List;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



import com.ttl.SpringBootJPACrudExample.dao.EmployeeRepository;
import com.ttl.SpringBootJPACrudExample.model.Employee;




@RestController
public class EmployeeController {



@Autowired
private EmployeeRepository obj;

@GetMapping("/employees")
public List<Employee> getAllEmployees()
{
return obj.findAll();
}

@RequestMapping("/")
String home() {
return "Hello TTL Employee -- Spring Boot!";
}



//localhost:8080/projectname/employee/1234 ==> 1234 @PathVariable id
@GetMapping(value = "/employee/{id}")
public Employee getEmployeeById(@PathVariable int empid) throws Exception {
System.out.println(this.getClass().getSimpleName() + " getEmployeeById() method invoked");
Optional<Employee> emp = obj.findById(empid);



if (!emp.isPresent())
throw new Exception("could not find Employee with id " + empid);



return emp.get();
}
}
